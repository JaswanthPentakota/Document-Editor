import React from 'react'
import './Table.css'
const Table = () => {
  return (
    <div className='Table-main-container'>
        <div>
            <label>Nani</label>
        </div>
    </div>
  )
}

export default Table
